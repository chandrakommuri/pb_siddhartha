<?php
	session_start();
	$username = $_POST["username"];
	$password = $_POST["password"];
	$response = array();
	if($username == "eassadmin" && $password == "mc8051#") {
		$_SESSION["login"] = "success";
		$response["status"] = "success";
		$response["message"] = "Login successful.";
	} else {
		$response["status"] = "error";
		$response["message"] = "Invalid Username/Password.";
	}
	echo json_encode($response);
?>