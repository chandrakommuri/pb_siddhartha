<?php
	session_start();
	$response = array();
	if(isset($_SESSION["login"]) && $_SESSION["login"] == "success") {
		$response["status"] = "success";
		$response["message"] = "Login successful.";
	} else {
		$response["status"] = "error";
		$response["message"] = "Invalid Username/Password.";
	}
	echo json_encode($response);
?>