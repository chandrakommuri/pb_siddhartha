<?php

	if(isset($_GET["section"]) && isset($_GET["batch"]))

	{

		$section=$_GET["section"];

		$batch=substr($_GET["batch"],2);

		require_once("db_connect.php");

		require_once("../model/course.php");



		$courses_query = "select vr.*, n.name from v_results vr, names n where vr.rollno = n.rollno and n.slno !=0 and vr.type not like 'Extra Curricular' and vr.section like '$section' and vr.rollno like '$batch%'";

		$courses_result = mysql_query($courses_query);

		

		$failed_courses = array();

		$passed_courses = array();

		while($row=mysql_fetch_assoc($courses_result))

		{

			$key = $row['rollno'].'-'.$row['name'];

			if($failed_courses[$key] == null)

			{

				$failed_courses[$key] = array();

			}

			if($passed_courses[$key] == null)

			{

				$passed_courses[$key] = array();

			}

			if($passed_courses[$key][$row['course_code']] != null)

			{

				continue;

			}

			$course = $failed_courses[$key][$row['course_code']];

			if($course == null)

			{

				$course = new Course();

				$course->semester = $row['semester'];

				$course->course_code = $row['course_code'];

				$course->title = $row['title'];

				$course->type = $row['type'];

				$course->month_year = $row['month_year'];

				$course->part = $row['part'];

				$course->internal = $row['internal'];

				$course->external = $row['external'];

				$course->total = $row['total'];

				$course->internal_pass = $row['internal_pass'];

				$course->external_pass = $row['external_pass'];

				$course->pass = $row['pass'];

				

				if($course->pass == 'F')

				{

					$failed_courses[$key][$row['course_code']] = $course;

				}

				else

				{

					$passed_courses[$key][$row['course_code']] = $course;

				}

			}

			else

			{

				if($course->internal < $row['internal'])

				{

					$course->internal = $row['internal'];

				}

				if($course->external < $row['external'])

				{

					$course->external = $row['external'];

				}

				

				$course->total = $course->internal + $course->external;

				if($course->part == '3' || $course->type == 'Practical' || substr($course->course_code,0,3) == 'FRE')

				{

					if($course->internal >= 4)

					{

						$course->internal_pass = 'P';

					}

					if($course->external >= 16)

					{

						$course->external_pass = 'P';

					}

				}

				else if($course->part != '4')

				{

					if($course->internal >= 10)

					{

						$course->internal_pass = 'P';

					}

					if($course->external >= 30)

					{

						$course->external_pass = 'P';

					}

				}



				if($course->internal_pass == 'P' && $course->external_pass == 'P')

				{

					unset($failed_courses[$key][$row['course_code']]);

					$passed_courses[$key][$row['course_code']] = $course;

				}

			}

		}

		

		echo json_encode($passed_courses);

	}

?>