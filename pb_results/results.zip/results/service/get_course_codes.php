<?php
    require_once("db_connect.php");
    $query = "select ccode, title from codes order by ccode";
    $result = mysql_query($query);
    $response = array();
    while($row = mysql_fetch_assoc($result))
    {
        array_push($response, $row);
    }
    echo json_encode($response);
?>