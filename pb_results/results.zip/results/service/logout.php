<?php
    session_start();
	$response = array();
	if(session_destroy()) {
        $response["status"] = "success";
		$response["message"] = "Logout successful.";
	} else {
        $_SESSION["login"] = null;
		$response["status"] = "error";
		$response["message"] = "Logout failed.";
	}
	echo json_encode($response);
?>