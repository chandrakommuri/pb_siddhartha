<?php
    $rollno = $_POST["rollno"];
    $course_code = $_POST["course_code"];
    $exam = $_POST["exam"];
    $marks = $_POST["marks"];
    $semester = $_POST["semester"];
    $month_year = $_POST["month_year"];
    require_once("db_connect.php");

    $ord = "1";
    $ord_query = "select ord from results where rollno='$rollno' and ccode='$course_code'";
    $result = mysql_query($ord_query);
    if($ord_row=mysql_fetch_row($result))
    {
        $ord = $ord_row[0];
    }

    $tp = null;
    $tp_query = "select tp from codes where ccode='$course_code'";
    $result = mysql_query($tp_query);
    if($tp_row=mysql_fetch_row($result))
    {
        $tp = $tp_row[0];
    }

    $query = "";
    if($exam == "I")
    {
        $query = "insert into results(rollno, ccode, tp, ie1, sem, my, ord) 
                    values('$rollno', '$course_code', '$tp', '$marks', '$semester', '$month_year', '$ord')";
    }
    else
    {
        $query = "insert into results(rollno, ccode, tp, se1, sem, my, ord)
                    values('$rollno', '$course_code', '$tp', '$marks', '$semester', '$month_year', '$ord')";
    }
    $result = mysql_query($query);
    $response = array();
    if($result)
	{
        $response["status"] = "success";
        $response["message"] = "Updated successfully.";
	}
	else
	{
		$response["status"] = "error";
		$response["message"] = "Update operation failed.";
	}
	echo json_encode($response);
?>